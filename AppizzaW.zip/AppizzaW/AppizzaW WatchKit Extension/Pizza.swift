//
//  Pizza.swift
//  AppizzaW
//
//  Created by Jorge Rochín. on 25/11/16.
//  Copyright © 2016 Jorge Rochín. All rights reserved.
//

import WatchKit

class Pizza: NSObject {

    var elTamaño:String=""
    var laMasa:String=""
    var elQueso:String=""
    var ingredientes: [String]? = [String]()
    static let aIngredientes = ["Jamón", "Pepperoni", "Pavo" , "Salchicha", "Aceituna", "Cebolla", "Pimiento", "Piña", "Anchoa", "Camarón", "Pulpo", "Chorizo"]
    
    class func obtenerIngrediente() -> [String] {
        return aIngredientes
    }
        
    func quitarIngrediente(ingrediente:String){
        if (self.ingredientes?.contains(ingrediente)) != nil {
            let index = self.ingredientes?.index(of: ingrediente)
            self.ingredientes?.remove(at: index!)
        }
    }
    
}

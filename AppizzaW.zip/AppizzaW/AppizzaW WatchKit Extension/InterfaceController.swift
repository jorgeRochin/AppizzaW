//
//  InterfaceController.swift
//  AppizzaW WatchKit Extension
//
//  Created by Jorge Rochín. on 24/11/16.
//  Copyright © 2016 Jorge Rochín. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet var pickerTamaño: WKInterfacePicker!
    
    var tamaños: [(String, String)] = [
        (" ", "Sel... Tamaño"),
        (" ", "Chica"),
        (" ", "Mediana"),
        (" ", "Grande")]
    var pizza = Pizza()
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        let pickerItems: [WKPickerItem] = tamaños.map {
            let pickerItem = WKPickerItem()
            pickerItem.caption = $0.0
            pickerItem.title = $0.1
            return pickerItem
        }
        pickerTamaño.setItems(pickerItems)
    }
    
    @IBAction func pickerChanged(_ value: Int) {
        pizza.elTamaño=tamaños[value].1
    }
    
    @IBAction func accionSiguiente() {
        let valorContexto = pizza
        pushController(withName: "IdentificadorMasa", context: valorContexto)
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}

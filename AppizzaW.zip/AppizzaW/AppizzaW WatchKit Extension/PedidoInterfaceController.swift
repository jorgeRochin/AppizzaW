//
//  PedidoInterfaceController.swift
//  AppizzaW
//
//  Created by Jorge Rochín. on 26/11/16.
//  Copyright © 2016 Jorge Rochín. All rights reserved.
//

import WatchKit
import Foundation


class PedidoInterfaceController: WKInterfaceController {

    @IBOutlet var lblTamaño: WKInterfaceLabel!
    @IBOutlet var lblMasa: WKInterfaceLabel!
    @IBOutlet var lblQueso: WKInterfaceLabel!
    @IBOutlet var lblIngrediente1: WKInterfaceLabel!
    @IBOutlet var lblIngrediente2: WKInterfaceLabel!
    @IBOutlet var lblIngrediente3: WKInterfaceLabel!
    @IBOutlet var lblIngrediente4: WKInterfaceLabel!
    @IBOutlet var lblIngrediente5: WKInterfaceLabel!
    var pizza = Pizza()
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        let c=context as! Pizza
        lblTamaño.setText(String(c.elTamaño))
        lblMasa.setText(String(c.laMasa))
        lblQueso.setText(String(c.elQueso))
        var ind:Int = 1
        for i in c.ingredientes! {
            switch ind {
            case 1:
                lblIngrediente1.setText("\(i)")
            case 2:
                lblIngrediente2.setText("\(i)")
            case 3:
                lblIngrediente3.setText("\(i)")
            case 4:
                lblIngrediente4.setText("\(i)")
            default:
                lblIngrediente5.setText("\(i)")
            }
            ind += 1
        }
        pizza = c
        
    }

    @IBAction func confirmar() {
        if pizza.elTamaño == "" {
            lblTamaño.setText("Seleccione Tamaño")
            return
        }
        
        if pizza.laMasa == "" {
            lblMasa.setText("Seleccione Masa")
            return
        }
        
        if pizza.elQueso == "" {
            lblQueso.setText("Seleccione Queso")
            return
        }
        
        if pizza.ingredientes == nil || (pizza.ingredientes?.count)! <= 0 {
            lblIngrediente1.setText("Seleccione Ingrediente")
            return
        }
        
        pushController(withName: "IdentificadorCocina", context: nil)
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}

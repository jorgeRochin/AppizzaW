//
//  IngredientesInterfaceController.swift
//  AppizzaW
//
//  Created by Jorge Rochín. on 26/11/16.
//  Copyright © 2016 Jorge Rochín. All rights reserved.
//

import WatchKit
import Foundation


class IngredientesInterfaceController: WKInterfaceController {

    @IBOutlet var botonSiguiente: WKInterfaceButton!
    @IBOutlet var botonJamon: WKInterfaceButton!
    @IBOutlet var botonPepperoni: WKInterfaceButton!
    @IBOutlet var botonPavo: WKInterfaceButton!
    @IBOutlet var botonSalchicha: WKInterfaceButton!
    @IBOutlet var botonAceituna: WKInterfaceButton!
    @IBOutlet var botonCebolla: WKInterfaceButton!
    @IBOutlet var botonPimiento: WKInterfaceButton!
    @IBOutlet var botonPiña: WKInterfaceButton!
    @IBOutlet var botonAnchoa: WKInterfaceButton!
    @IBOutlet var botonCamaron: WKInterfaceButton!
    @IBOutlet var botonPulpo: WKInterfaceButton!
    @IBOutlet var botonChorizo: WKInterfaceButton!
    
    var pizza = Pizza()
    var botonSeleccionado = false
    var jamon = false
    var pepperoni = false
    var pavo = false
    var salchicha = false
    var aceituna = false
    var cebolla = false
    var pimiento = false
    var piña = false
    var anchoa = false
    var camaron = false
    var pulpo = false
    var chorizo = false
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        let c=context as! Pizza
        pizza.elTamaño = c.elTamaño
        pizza.laMasa = c.laMasa
        pizza.elQueso = c.elQueso
        botonSiguiente.setEnabled(false)
    }

    @IBAction func accionJamon() {
        if jamon{
            botonJamon.setBackgroundColor(UIColor(red: 255, green: 255, blue: 255, alpha: 1))
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[0])
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.setEnabled(false)
            }
            jamon = !jamon
        }
        else{
            if (pizza.ingredientes?.endIndex)! < 5 {
                botonJamon.setBackgroundColor(UIColor(red: 192, green: 192, blue: 192, alpha: 1))
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[0])
                botonSiguiente.setEnabled(true)
                jamon = !jamon
            }
        }
    }
    
    @IBAction func accionPepperoni() {
        if pepperoni{
            botonPepperoni.setBackgroundColor(UIColor(red: 255, green: 255, blue: 255, alpha: 1))
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[1])
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.setEnabled(false)
            }
            pepperoni = !pepperoni
        }
        else{
            if (pizza.ingredientes?.endIndex)! < 5 {
                botonPepperoni.setBackgroundColor(UIColor(red: 192, green: 192, blue: 192, alpha: 1))
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[1])
                botonSiguiente.setEnabled(true)
                pepperoni = !pepperoni
            }
        }
    }
    
    @IBAction func accionPavo() {
        if pavo{
            botonPavo.setBackgroundColor(UIColor(red: 255, green: 255, blue: 255, alpha: 1))
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[2])
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.setEnabled(false)
            }
            pavo = !pavo
        }
        else{
            if (pizza.ingredientes?.endIndex)! < 5 {
                botonPavo.setBackgroundColor(UIColor(red: 192, green: 192, blue: 192, alpha: 1))
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[2])
                botonSiguiente.setEnabled(true)
                pavo = !pavo
            }
        }
    }

    @IBAction func accionSalchicha() {
        if salchicha{
            botonSalchicha.setBackgroundColor(UIColor(red: 255, green: 255, blue: 255, alpha: 1))
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[3])
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.setEnabled(false)
            }
            salchicha = !salchicha
        }
        else{
            if (pizza.ingredientes?.endIndex)! < 5 {
                botonSalchicha.setBackgroundColor(UIColor(red: 192, green: 192, blue: 192, alpha: 1))
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[3])
                botonSiguiente.setEnabled(true)
                salchicha = !salchicha
            }
        }
    }
    
    @IBAction func accionAceituna() {
        if aceituna{
            botonAceituna.setBackgroundColor(UIColor(red: 255, green: 255, blue: 255, alpha: 1))
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[4])
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.setEnabled(false)
            }
            aceituna = !aceituna
        }
        else{
            if (pizza.ingredientes?.endIndex)! < 5 {
                botonAceituna.setBackgroundColor(UIColor(red: 192, green: 192, blue: 192, alpha: 1))
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[4])
                botonSiguiente.setEnabled(true)
                aceituna = !aceituna
            }
        }
    }
    
    @IBAction func accionCebolla() {
        if cebolla{
            botonCebolla.setBackgroundColor(UIColor(red: 255, green: 255, blue: 255, alpha: 1))
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[5])
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.setEnabled(false)
            }
            cebolla = !cebolla
        }
        else{
            if (pizza.ingredientes?.endIndex)! < 5 {
                botonCebolla.setBackgroundColor(UIColor(red: 192, green: 192, blue: 192, alpha: 1))
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[5])
                botonSiguiente.setEnabled(true)
                cebolla = !cebolla
            }
        }
    }
    
    @IBAction func accionPimiento() {
        if pimiento{
            botonPimiento.setBackgroundColor(UIColor(red: 255, green: 255, blue: 255, alpha: 1))
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[6])
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.setEnabled(false)
            }
            pimiento = !pimiento
        }
        else{
            if (pizza.ingredientes?.endIndex)! < 5 {
                botonPimiento.setBackgroundColor(UIColor(red: 192, green: 192, blue: 192, alpha: 1))
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[6])
                botonSiguiente.setEnabled(true)
                pimiento = !pimiento
            }
        }
    }
    
    @IBAction func accionPiña() {
        if piña{
            botonPiña.setBackgroundColor(UIColor(red: 255, green: 255, blue: 255, alpha: 1))
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[7])
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.setEnabled(false)
            }
            piña = !piña
        }
        else{
            if (pizza.ingredientes?.endIndex)! < 5 {
                botonPiña.setBackgroundColor(UIColor(red: 192, green: 192, blue: 192, alpha: 1))
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[7])
                botonSiguiente.setEnabled(true)
                piña = !piña
            }
        }
    }
    
    @IBAction func accionAnchoa() {
        if anchoa{
            botonAnchoa.setBackgroundColor(UIColor(red: 255, green: 255, blue: 255, alpha: 1))
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[8])
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.setEnabled(false)
            }
            anchoa = !anchoa
        }
        else{
            if (pizza.ingredientes?.endIndex)! < 5 {
                botonAnchoa.setBackgroundColor(UIColor(red: 192, green: 192, blue: 192, alpha: 1))
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[8])
                botonSiguiente.setEnabled(true)
                anchoa = !anchoa
            }
        }
    }
    
    @IBAction func accionCamaron() {
        if camaron{
            botonCamaron.setBackgroundColor(UIColor(red: 255, green: 255, blue: 255, alpha: 1))
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[9])
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.setEnabled(false)
            }
            camaron = !camaron
        }
        else{
            if (pizza.ingredientes?.endIndex)! < 5 {
                botonCamaron.setBackgroundColor(UIColor(red: 192, green: 192, blue: 192, alpha: 1))
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[9])
                botonSiguiente.setEnabled(true)
                camaron = !camaron
            }
        }
    }
    
    @IBAction func accionPulpo() {
        if pulpo{
            botonPulpo.setBackgroundColor(UIColor(red: 255, green: 255, blue: 255, alpha: 1))
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[10])
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.setEnabled(false)
            }
            pulpo = !pulpo
        }
        else{
            if (pizza.ingredientes?.endIndex)! < 5 {
                botonPulpo.setBackgroundColor(UIColor(red: 192, green: 192, blue: 192, alpha: 1))
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[10])
                botonSiguiente.setEnabled(true)
                pulpo = !pulpo
            }
        }
    }
    
    @IBAction func accionChorizo() {
        if chorizo{
            botonChorizo.setBackgroundColor(UIColor(red: 255, green: 255, blue: 255, alpha: 1))
            pizza.quitarIngrediente(ingrediente: Pizza.obtenerIngrediente()[11])
            if (pizza.ingredientes?.isEmpty)! {
                botonSiguiente.setEnabled(false)
            }
            chorizo = !chorizo
        }
        else{
            if (pizza.ingredientes?.endIndex)! < 5 {
                botonChorizo.setBackgroundColor(UIColor(red: 192, green: 192, blue: 192, alpha: 1))
                pizza.ingredientes?.append(Pizza.obtenerIngrediente()[11])
                botonSiguiente.setEnabled(true)
                chorizo = !chorizo
            }
        }
    }
    
    @IBAction func accionSiguiente() {
        let valorContexto = pizza
        pushController(withName: "IdentificadorPedido", context: valorContexto)
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}

//
//  MasaInterfaceController.swift
//  AppizzaW
//
//  Created by Jorge Rochín. on 26/11/16.
//  Copyright © 2016 Jorge Rochín. All rights reserved.
//

import WatchKit
import Foundation


class MasaInterfaceController: WKInterfaceController {

    @IBOutlet var pickerMasa: WKInterfacePicker!
    var masas: [(String, String)] = [
        (" ", "Sel... Masa"),
        (" ", "Delgada"),
        (" ", "Crujiente"),
        (" ", "Gruesa")]
    var pizza = Pizza()
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        let c=context as! Pizza
        pizza.elTamaño = c.elTamaño
        let pickerItems: [WKPickerItem] = masas.map {
            let pickerItem = WKPickerItem()
            pickerItem.caption = $0.0
            pickerItem.title = $0.1
            return pickerItem
        }
        pickerMasa.setItems(pickerItems)
    }

    @IBAction func pickerChanged(_ value: Int) {
        pizza.laMasa = masas[value].1
    }
    
    @IBAction func accionSiguiente() {
        let valorContexto = pizza
        pushController(withName: "IdentificadorQueso", context: valorContexto)
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
